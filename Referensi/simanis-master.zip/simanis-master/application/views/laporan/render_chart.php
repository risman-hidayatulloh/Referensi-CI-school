<?php
if ($graph) {
	foreach ($graph as $m => $n) {
		echo($n.'<br/><br/>');
	}
}