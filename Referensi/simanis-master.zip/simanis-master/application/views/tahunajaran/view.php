<?php
echo $js_grid;
?>

<h3>Manajemen Data Tahun Ajaran</h3>
<h2>Daftar Tahun Ajaran</h2>
<br/>
<table id="flex1" style="display:none"></table>
<br />
<table>
	<tr>
		<td class="table-common-links">
			<a href="<?=base_url();?>tahunajaran/data" id="add">Tambah Tahun Ajaran</a>
		</td>
	</tr>
</table>