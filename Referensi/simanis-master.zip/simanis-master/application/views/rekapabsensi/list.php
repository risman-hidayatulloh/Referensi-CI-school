<?php
echo $js_grid;
?>
<table id="flex1" style="display:none"></table>
<br />
<table>
	<tr>
		<td class="table-common-links">
			<a href="<?=base_url()?>rekapabsensi/ekspor/<?=$url['tglawal']?>/<?=$url['tglakhir']?>/<?=$url['nis']?>/<?=$url['kelas']?>" id="add">Ekspor ke Excel</a>
		</td>
	</tr>
</table>	
</body>
