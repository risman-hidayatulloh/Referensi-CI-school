<?php
echo $js_grid;
?>

<h3>Manajemen Data Semester</h3>
<h2>Daftar Semester</h2>
<br/>
<table id="flex1" style="display:none"></table>
<br />
<table>
	<tr>
		<td class="table-common-links">
			<a href="<?=base_url();?>semester/data" id="add">Tambah Semester</a>
		</td>
	</tr>
</table>