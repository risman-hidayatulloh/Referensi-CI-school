<?php
echo $js_grid;
?>

<h3>Manajemen Data Voucher</h3>
<h2>Daftar Voucher</h2>
<br/>
<table id="flex1" style="display:none"></table>
<br />
<table>
	<tr>
		<td class="table-common-links">
			<a href="<?=base_url();?>voucher/data" id="add">Tambah Data Voucher</a>
		</td>
	</tr>
</table>