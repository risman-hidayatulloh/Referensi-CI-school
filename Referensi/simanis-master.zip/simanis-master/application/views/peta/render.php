<center>
	<embed width="700" height="500" src="<?=base_url();?>map/kel.psvg?id=<?=$id_client?>&tahun=<?=$tahun?>" type="image/svg+xml" />
</center>