<?php
echo $js_grid;
?>

<h3>Manajemen Data Siswa & Aktifitas</h3>
<h2>Daftar Data Siswa</h2>
<br/>
<table id="flex1" style="display:none"></table>
<br />
<table>
	<tr>
		<td class="table-common-links">
			<a href="<?=base_url();?>siswa/data" id="add">Tambah Data Siswa</a><a href="<?=base_url();?>siswa/excel">Import Data Siswa</a>
		</td>
	</tr>
</table>