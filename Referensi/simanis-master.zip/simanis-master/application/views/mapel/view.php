<?php
echo $js_grid;
?>

<h3>Manajemen Data Pendukung</h3>
<h2>Daftar Data Mata Pelajaran</h2>
<br/>
<table id="flex1" style="display:none"></table>
<br />
<table>
	<tr>
		<td class="table-common-links">
			<a href="<?=base_url();?>mapel/data" id="add">Tambah Data Mata Pelajaran</a>
		</td>
	</tr>
</table>