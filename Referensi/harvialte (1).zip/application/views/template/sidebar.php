<aside class="main-sidebar">
    <section class="sidebar">
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo base_url('assets/AdminLTE-2.0.5/dist/img/user2-160x160.jpg') ?>" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
                <?php $user = $this->ion_auth->user()->row() ?>
                <p><?php echo $user->username ?></p>

                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo site_url('') ?>"><i class="fa fa-circle-o"></i> Dashboard v1</a></li>
                    <li><a href="<?php echo site_url('dashboard2') ?>"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>
                </ul>
            </li>
            
            <li><a href="<?php echo site_url('peserta') ?>"><i class="fa fa-users"></i> <span>Peserta</span></a></li>
            <li class="header">Setting</li>
            <li><a href="<?php echo site_url('harviacode') ?>" target="_blank"><i class="fa fa-wrench"></i> <span>CRUD</span></a></li>
        </ul>
    </section>
</aside>
<div class="content-wrapper">