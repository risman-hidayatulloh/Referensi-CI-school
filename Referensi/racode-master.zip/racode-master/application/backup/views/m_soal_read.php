
        <!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                <h3 class='box-title'>M_soal Read</h3>
        <table class="table table-bordered">
	    <tr><td>Id Guru</td><td><?php echo $id_guru; ?></td></tr>
	    <tr><td>Id Mapel</td><td><?php echo $id_mapel; ?></td></tr>
	    <tr><td>Bobot</td><td><?php echo $bobot; ?></td></tr>
	    <tr><td>Gambar</td><td><?php echo $gambar; ?></td></tr>
	    <tr><td>Soal</td><td><?php echo $soal; ?></td></tr>
	    <tr><td>Opsi A</td><td><?php echo $opsi_a; ?></td></tr>
	    <tr><td>Opsi B</td><td><?php echo $opsi_b; ?></td></tr>
	    <tr><td>Opsi C</td><td><?php echo $opsi_c; ?></td></tr>
	    <tr><td>Opsi D</td><td><?php echo $opsi_d; ?></td></tr>
	    <tr><td>Opsi E</td><td><?php echo $opsi_e; ?></td></tr>
	    <tr><td>Jawaban</td><td><?php echo $jawaban; ?></td></tr>
	    <tr><td>Tgl Input</td><td><?php echo $tgl_input; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('soal') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->