# Sina
Aplikasis Sistem Nilai Informasi Akademik Sederhana 
menggunakan framework CodeIgniter
