<div class="well">
        	<div class="container">
        	<p>&copy; 2014</p>
            <address>
            	<p><i class="glyphicon glyphicon-map-marker"></i><strong>Alamat:</strong>
                Jl.Jumbang No.14 Bogor Jawa Barat Indonesia<br>
                <i class="glyphicon glyphicon-phone-alt"></i><strong>Telephone:</strong> +622251</p> 
                </address>
        	</div>
        </div>
    </body>
</html>

<!-- JS -->
<script src="<?PHP echo base_url(); ?>assets/js/jquery-2.1.1.min.js"></script>
<script src="<?PHP echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?PHP echo base_url(); ?>assets/js/jquery.dataTables.min.js"></script>
<script src="<?PHP echo base_url(); ?>assets/js/plugins/ckeditor/ckeditor.js"></script>
