# Sistem Informasi Akademik Sekolah
Source code sistem informasi ini merupakan hasil belajar dari DVD Tutorial Membangun sistem informasi akademik 
sekolah dengan framework codeigniter 3 dan Template Clip One. source code ini saya bagikan secara gratis. 

# Cara Install
Silahkan clone project ini, buat database baru dengan nama akademik lalu import database akademik.sql, lalu sesuaikan pengaturan konfigurasi database pada application/config/database.php .
# User Login
Level Admin =  username : nuris123, password : 123
<br>
Level Guru  = username : udin123, password : udin123
<br>
https://belajarphp.net/product/sistem-informasi-sekolah/
