<?php
class CFPDF {
    
    function __construct() {
        
    require_once APPPATH.'/libraries/fpdf.php';

    }
    
    
}